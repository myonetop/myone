<?php
$max=10;
$test_smtp=0;
$domeniu="";
$link="";
$sender_name='=?UTF-8?B?'.base64_encode('test').'?=';
$subject = "[ SUMMARY REPORT ] - TEST ! - DATE : ".date('d F Y')." ID : ";
?>
